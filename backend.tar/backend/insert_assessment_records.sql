INSERT INTO assessments(student_id,subject_id,grade_id,assessment_period,rit_score,year) VALUES 
(21,3,11,"Fall",125,2022),
(21,3,11,"Winter",120,2022),
(21,3,11,"Spring",135,2022),
(21,3,11,"Fall",130,2023),
(21,3,11,"Winter",125,2023),
(21,3,11,"Spring",140,2023),
(21,3,11,"Fall",135,2024),
(21,3,11,"Winter",140,2024),
(21,3,11,"Spring",125,2024),
(21,3,11,"Fall",130,2025),
(21,3,11,"Winter",120,2025),
(21,3,11,"Spring",152,2025);




INSERT INTO assessments(student_id,subject_id,grade_id,assessment_period,rit_score,year) VALUES 
(22,3,11,"Fall",130,2022),
(22,3,11,"Winter",170,2022),
(22,3,11,"Spring",140,2022),
(22,3,11,"Fall",130,2023),
(22,3,11,"Winter",135,2023),
(22,3,11,"Spring",130,2023),
(22,3,11,"Fall",135,2024),
(22,3,11,"Winter",140,2024),
(22,3,11,"Spring",145,2024),
(22,3,11,"Fall",141,2025),
(22,3,11,"Winter",133,2025),
(22,3,11,"Spring",127,2025);


INSERT INTO assessments(student_id,subject_id,grade_id,assessment_period,rit_score,year) VALUES 
(23,3,11,"Fall",220,2022),
(23,3,11,"Winter",175,2022),
(23,3,11,"Spring",170,2022),
(23,3,11,"Fall",175,2023),
(23,3,11,"Winter",170,2023),
(23,3,11,"Spring",170,2023),
(23,3,11,"Fall",145,2024),
(23,3,11,"Winter",130,2024),
(23,3,11,"Spring",215,2024),
(23,3,11,"Fall",135,2025),
(23,3,11,"Winter",140,2025),
(23,3,11,"Spring",130,2025);


INSERT INTO assessments(student_id,subject_id,grade_id,assessment_period,rit_score,year) VALUES 
(24,3,11,"Fall",225,2022),
(24,3,11,"Winter",220,2022),
(24,3,11,"Spring",215,2022),
(24,3,11,"Fall",180,2023),
(24,3,11,"Winter",175,2023),
(24,3,11,"Spring",210,2023),
(24,3,11,"Fall",150,2024),
(24,3,11,"Winter",135,2024),
(24,3,11,"Spring",160,2024),
(24,3,11,"Fall",140,2025),
(24,3,11,"Winter",145,2025),
(24,3,11,"Spring",135,2025);



INSERT INTO assessments(student_id,subject_id,grade_id,assessment_period,rit_score,year) VALUES 
(31,3,11,"Fall",230,2022),
(31,3,11,"Winter",225,2022),
(31,3,11,"Spring",220,2022),
(31,3,11,"Fall",210,2023),
(31,3,11,"Winter",215,2023),
(31,3,11,"Spring",215,2023),
(31,3,11,"Fall",170,2024),
(31,3,11,"Winter",175,2024),
(31,3,11,"Spring",165,2024),
(31,3,11,"Fall",145,2025),
(31,3,11,"Winter",150,2025),
(31,3,11,"Spring",140,2025);



INSERT INTO assessments(student_id,subject_id,grade_id,assessment_period,rit_score,year) VALUES 
(32,3,11,"Fall",260,2022),
(32,3,11,"Winter",230,2022),
(32,3,11,"Spring",225,2022),
(32,3,11,"Fall",215,2023),
(32,3,11,"Winter",260,2023),
(32,3,11,"Spring",260,2023),
(32,3,11,"Fall",210,2024),
(32,3,11,"Winter",180,2024),
(32,3,11,"Spring",215,2024),
(32,3,11,"Fall",170,2025),
(32,3,11,"Winter",175,2025),
(32,3,11,"Spring",170,2025);



INSERT INTO assessments(student_id,subject_id,grade_id,assessment_period,rit_score,year) VALUES 
(33,3,11,"Fall",270,2022),
(33,3,11,"Winter",265,2022),
(33,3,11,"Spring",260,2022),
(33,3,11,"Fall",265,2023),
(33,3,11,"Winter",270,2023),
(33,3,11,"Spring",253,2023),
(33,3,11,"Fall",215,2024),
(33,3,11,"Winter",210,2024),
(33,3,11,"Spring",220,2024),
(33,3,11,"Fall",214,2025),
(33,3,11,"Winter",221,2025),
(33,3,11,"Spring",227,2025);


INSERT INTO assessments(student_id,subject_id,grade_id,assessment_period,rit_score,year) VALUES 
(34,3,11,"Fall",320,2022),
(34,3,11,"Winter",315,2022),
(34,3,11,"Spring",310,2022),
(34,3,11,"Fall",280,2023),
(34,3,11,"Winter",290,2023),
(34,3,11,"Spring",290,2023),
(34,3,11,"Fall",270,2024),
(34,3,11,"Winter",275,2024),
(34,3,11,"Spring",270,2024),
(34,3,11,"Fall",274,2025),
(34,3,11,"Winter",281,2025),
(34,3,11,"Spring",295,2025);